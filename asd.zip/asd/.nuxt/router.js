import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _658b0d22 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _38b03033 = () => interopDefault(import('..\\pages\\index\\index.vue' /* webpackChunkName: "pages_index_index" */))
const _3bb6716c = () => interopDefault(import('..\\pages\\index\\community.vue' /* webpackChunkName: "pages_index_community" */))
const _6c029a12 = () => interopDefault(import('..\\pages\\index\\eventDetails.vue' /* webpackChunkName: "pages_index_eventDetails" */))
const _e3e00dca = () => interopDefault(import('..\\pages\\index\\my.vue' /* webpackChunkName: "pages_index_my" */))
const _0c223102 = () => interopDefault(import('..\\pages\\index\\news.vue' /* webpackChunkName: "pages_index_news" */))
const _09459d73 = () => interopDefault(import('..\\pages\\index\\newsDetail.vue' /* webpackChunkName: "pages_index_newsDetail" */))
const _342d2911 = () => interopDefault(import('..\\pages\\index\\offlineActivities.vue' /* webpackChunkName: "pages_index_offlineActivities" */))
const _10f23ec6 = () => interopDefault(import('..\\pages\\index\\onlineCourses.vue' /* webpackChunkName: "pages_index_onlineCourses" */))
const _1f3b34ca = () => interopDefault(import('..\\pages\\index\\playback.vue' /* webpackChunkName: "pages_index_playback" */))
const _f40c79ae = () => interopDefault(import('..\\pages\\index\\wxLogin.vue' /* webpackChunkName: "pages_index_wxLogin" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/",
      component: _658b0d22,
      children: [{
        path: "",
        component: _38b03033,
        name: "index"
      }, {
        path: "community",
        component: _3bb6716c,
        name: "index-community"
      }, {
        path: "eventDetails",
        component: _6c029a12,
        name: "index-eventDetails"
      }, {
        path: "my",
        component: _e3e00dca,
        name: "index-my"
      }, {
        path: "news",
        component: _0c223102,
        name: "index-news"
      }, {
        path: "newsDetail",
        component: _09459d73,
        name: "index-newsDetail"
      }, {
        path: "offlineActivities",
        component: _342d2911,
        name: "index-offlineActivities"
      }, {
        path: "onlineCourses",
        component: _10f23ec6,
        name: "index-onlineCourses"
      }, {
        path: "playback",
        component: _1f3b34ca,
        name: "index-playback"
      }, {
        path: "wxLogin",
        component: _f40c79ae,
        name: "index-wxLogin"
      }]
    }],

    fallback: false
  })
}
